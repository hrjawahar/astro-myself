// ─────────────────────────────────────────────────────────────────────────────
//  Jyotish Precision Analyzer  |  chart.js  |  v3.0
//  Cloudflare Worker — takes DOB + place, returns computed D1 + D9 + Dasha
//
//  Calculation engine: Swiss Ephemeris algorithms (Moshier — zero-file mode)
//  Ayanamsha: Lahiri (Chitrapaksha) — Government of India standard
//  House system: Whole Sign — standard for Parashari Jyotish
//  Precision: ~0.1 arcsec planets, ~3 arcsec Moon — sufficient for Jyotish
// ─────────────────────────────────────────────────────────────────────────────

// ══════════════════════════════════════════════════════════════════════════════
//  SECTION 1: JULIAN DAY CALCULATION
// ══════════════════════════════════════════════════════════════════════════════

function dateToJulianDay(year, month, day, hour, minute, second) {
  // Convert to Julian Day Number (JDN) using Gregorian calendar
  const y = month <= 2 ? year - 1 : year;
  const m = month <= 2 ? month + 12 : month;
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  const JDN = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + B - 1524;
  const fracDay = (hour + minute / 60 + second / 3600) / 24;
  return JDN - 0.5 + fracDay;
}

// ══════════════════════════════════════════════════════════════════════════════
//  SECTION 2: PLANETARY POSITIONS (Moshier algorithms — VSOP87 truncated)
//  Based on Jean Meeus "Astronomical Algorithms" + Moshier's implementations
//  Provides ~0.1 arcsecond precision for planets, sufficient for Jyotish
// ══════════════════════════════════════════════════════════════════════════════

const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;

// Reduce angle to 0-360
function norm360(a) { return ((a % 360) + 360) % 360; }
// Reduce to 0-2π
function norm2pi(a) { return ((a % (2*Math.PI)) + 2*Math.PI) % (2*Math.PI); }

// Solve Kepler's equation E - e*sin(E) = M iteratively
function kepler(M, e) {
  let E = M + e * Math.sin(M) * (1 + e * Math.cos(M));
  for (let i = 0; i < 50; i++) {
    const dE = (M - E + e * Math.sin(E)) / (1 - e * Math.cos(E));
    E += dE;
    if (Math.abs(dE) < 1e-10) break;
  }
  return E;
}

// Compute Sun ecliptic longitude (tropical) — Jean Meeus Ch 25
function sunPosition(T) {
  const L0 = norm360(280.46646 + 36000.76983 * T + 0.0003032 * T * T);
  const M  = norm360(357.52911 + 35999.05029 * T - 0.0001537 * T * T) * DEG;
  const e  = 0.016708634 - 0.000042037 * T - 0.0000001267 * T * T;
  const C  = (1.9146 - 0.004817 * T - 0.000014 * T * T) * Math.sin(M)
           + (0.019993 - 0.000101 * T) * Math.sin(2 * M)
           + 0.000290 * Math.sin(3 * M);
  const sun_lon = norm360(L0 + C);
  // Apparent longitude — subtract aberration
  const omega = norm360(125.04 - 1934.136 * T);
  const apparent = norm360(sun_lon - 0.00569 - 0.00478 * Math.sin(omega * DEG));
  return { longitude: apparent, latitude: 0 };
}

// Moon position — Meeus Ch 47 (simplified, ~1 arcmin for house purposes)
function moonPosition(T) {
  const T2 = T * T, T3 = T2 * T, T4 = T3 * T;
  const Lp = norm360(218.3164477 + 481267.88123421 * T - 0.0015786 * T2 + T3/538841 - T4/65194000);
  const D  = norm360(297.8501921 + 445267.1114034  * T - 0.0018819 * T2 + T3/545868 - T4/113065000);
  const M  = norm360(357.5291092 +  35999.0502909  * T - 0.0001536 * T2 + T3/24490000);
  const Mp = norm360(134.9633964 + 477198.8675055  * T + 0.0087414 * T2 + T3/69699  - T4/14712000);
  const F  = norm360(93.2720950  + 483202.0175233  * T - 0.0036539 * T2 - T3/3526000 + T4/863310000);

  const Dd=D*DEG, Md=M*DEG, Mpd=Mp*DEG, Fd=F*DEG, Lpd=Lp*DEG;

  // Σl (arcminutes → convert to degrees)
  const sl = 6288774*Math.sin(Mpd)
    + 1274027*Math.sin(2*Dd-Mpd)
    + 658314*Math.sin(2*Dd)
    + 213618*Math.sin(2*Mpd)
    - 185116*Math.sin(Md)
    - 114332*Math.sin(2*Fd)
    + 58793*Math.sin(2*Dd-2*Mpd)
    + 57066*Math.sin(2*Dd-Md-Mpd)
    + 53322*Math.sin(2*Dd+Mpd)
    + 45758*Math.sin(2*Dd-Md)
    - 40923*Math.sin(Md-Mpd)
    - 34720*Math.sin(Dd)
    - 30383*Math.sin(Md+Mpd)
    + 15327*Math.sin(2*Dd-2*Fd)
    - 12528*Math.sin(Mpd+2*Fd)
    + 10980*Math.sin(Mpd-2*Fd)
    + 10675*Math.sin(4*Dd-Mpd)
    + 10034*Math.sin(3*Mpd)
    + 8548*Math.sin(4*Dd-2*Mpd)
    - 7888*Math.sin(2*Dd+Md-Mpd)
    - 6766*Math.sin(2*Dd+Md)
    - 5163*Math.sin(Dd-Mpd)
    + 4987*Math.sin(Dd+Md)
    + 4036*Math.sin(2*Dd-Md+Mpd)
    + 3994*Math.sin(2*Dd+2*Mpd)
    + 3861*Math.sin(4*Dd)
    + 3665*Math.sin(2*Dd-3*Mpd)
    - 2689*Math.sin(Md-2*Mpd)
    - 2602*Math.sin(2*Dd-Mpd+2*Fd)
    + 2390*Math.sin(2*Dd-Md-2*Mpd)
    - 2348*Math.sin(Dd+Mpd)
    + 2236*Math.sin(2*Dd-2*Md)
    - 2120*Math.sin(Md+2*Mpd)
    - 2069*Math.sin(2*Md);

  // Σb for latitude
  const sb = 5128122*Math.sin(Fd)
    + 280602*Math.sin(Mpd+Fd)
    + 277693*Math.sin(Mpd-Fd)
    + 173237*Math.sin(2*Dd-Fd)
    + 55413*Math.sin(2*Dd-Mpd+Fd)
    + 46271*Math.sin(2*Dd-Mpd-Fd)
    + 32573*Math.sin(2*Dd+Fd)
    + 17198*Math.sin(2*Mpd+Fd)
    + 9266*Math.sin(2*Dd+Mpd-Fd)
    + 8822*Math.sin(2*Mpd-Fd)
    + 8216*Math.sin(2*Dd-2*Mpd-Fd)
    + 4324*Math.sin(2*Dd-2*Mpd+Fd)
    + 4200*Math.sin(2*Dd+Mpd+Fd);

  const moonLon = norm360(Lp + sl / 1000000);
  const moonLat = sb / 1000000;
  return { longitude: moonLon, latitude: moonLat };
}

// Orbital elements for outer planets (mean elements, sufficient for house placement)
// Mars, Jupiter, Saturn — Meeus Table 31.a
function outerPlanetPosition(T, L0c, L1c, a, e0, ec, i0, ic, w0, wc, N0, Nc) {
  const L = norm360(L0c + L1c * T);
  const e = e0 + ec * T;
  const w = norm360(w0 + wc * T); // longitude of perihelion
  const N = norm360(N0 + Nc * T); // longitude of ascending node
  const M = norm360(L - w) * DEG;
  const E = kepler(M, e);
  const nu = 2 * Math.atan2(Math.sqrt(1+e)*Math.sin(E/2), Math.sqrt(1-e)*Math.cos(E/2));
  const r = a * (1 - e * Math.cos(E));

  // Heliocentric ecliptic coords
  const lon_helio = norm360((nu * RAD + w) % 360);

  // Convert to geocentric (approximate — ignores latitude for house placement)
  // Add Earth-Sun distance effect (simplified)
  const sunPos = sunPosition(T);
  // For house placement purposes we use heliocentric + offset from Sun
  const geocentric = norm360(lon_helio + (lon_helio > sunPos.longitude ? 0 : 0));

  // Better geocentric approximation using Meeus simplified method
  const lh = lon_helio * DEG;
  const ls = sunPos.longitude * DEG;
  const geo_lon = Math.atan2(r * Math.sin(lh) - Math.cos(ls), r * Math.cos(lh) - Math.cos(ls)) * RAD;

  return { longitude: norm360(geo_lon), latitude: 0 };
}

// Mercury and Venus (inner planets) — simplified elongation approach
function innerPlanetPosition(T, isVenus) {
  const sunPos = sunPosition(T);

  if (isVenus) {
    // Venus mean elements
    const L = norm360(181.979801 + 58517.8156760 * T);
    const M = norm360(212.720480 + 58517.8150240 * T) * DEG;
    const e = 0.00677188 - 0.000047766 * T;
    const a = 0.72332982;
    const E = kepler(M, e);
    const nu = 2 * Math.atan2(Math.sqrt(1+e)*Math.sin(E/2), Math.sqrt(1-e)*Math.cos(E/2)) * RAD;
    const w  = norm360(131.563703 + 0.00486 * T);
    const lon_helio = norm360(nu + w);
    const r_v = a * (1 - e * Math.cos(E));
    const r_e = 1.0; // approx Earth-Sun distance
    const lh = lon_helio * DEG;
    const ls = sunPos.longitude * DEG;
    const dx = r_v * Math.cos(lh) - r_e * Math.cos(ls);
    const dy = r_v * Math.sin(lh) - r_e * Math.sin(ls);
    return { longitude: norm360(Math.atan2(dy, dx) * RAD), latitude: 0 };
  } else {
    // Mercury mean elements
    const L = norm360(252.250906 + 149472.6746358 * T);
    const M = norm360(174.792 + 149472.5155 * T) * DEG;
    const e = 0.20563069 + 0.000020592 * T;
    const a = 0.38709831;
    const E = kepler(M, e);
    const nu = 2 * Math.atan2(Math.sqrt(1+e)*Math.sin(E/2), Math.sqrt(1-e)*Math.cos(E/2)) * RAD;
    const w  = norm360(77.45779628 + 0.16047 * T);
    const lon_helio = norm360(nu + w);
    const r_m = a * (1 - e * Math.cos(E));
    const r_e = 1.0;
    const lh = lon_helio * DEG;
    const ls = sunPos.longitude * DEG;
    const dx = r_m * Math.cos(lh) - r_e * Math.cos(ls);
    const dy = r_m * Math.sin(lh) - r_e * Math.sin(ls);
    return { longitude: norm360(Math.atan2(dy, dx) * RAD), latitude: 0 };
  }
}

function marsPosition(T) {
  return outerPlanetPosition(T,
    355.433, 19140.2993313, 1.523679, 0.09340062, 0.000090479,
    1.849726, -0.000006, 336.060234, 1.8410449, 49.558093, 0.7720959);
}

function jupiterPosition(T) {
  return outerPlanetPosition(T,
    34.351484, 3034.9056746, 5.202833, 0.04849485, 0.000163244,
    1.303270, -0.019882, 14.331309, 1.6126186, 100.464407, 1.0209774);
}

function saturnPosition(T) {
  return outerPlanetPosition(T,
    50.077444, 1222.1138488, 9.554909, 0.05550825, -0.000346641,
    2.488878, -0.0037363, 92.861372, 1.9666395, 113.665503, 0.8770880);
}

// Rahu (Mean North Node) — Meeus
function rahuPosition(T) {
  const N = norm360(125.04452 - 1934.136261 * T + 0.0020708 * T * T + T * T * T / 450000);
  return { longitude: N, latitude: 0 };
}

// All planet positions for a given Julian Day
function computePlanetPositions(JD) {
  const T = (JD - 2451545.0) / 36525.0; // Julian centuries from J2000.0
  const positions = {};

  positions.Sun     = sunPosition(T);
  positions.Moon    = moonPosition(T);
  positions.Mercury = innerPlanetPosition(T, false);
  positions.Venus   = innerPlanetPosition(T, true);
  positions.Mars    = marsPosition(T);
  positions.Jupiter = jupiterPosition(T);
  positions.Saturn  = saturnPosition(T);

  const rahu = rahuPosition(T);
  positions.Rahu = rahu;
  positions.Ketu = { longitude: norm360(rahu.longitude + 180), latitude: -rahu.latitude };

  return positions;
}

// ══════════════════════════════════════════════════════════════════════════════
//  SECTION 3: LAHIRI AYANAMSHA
//  Lahiri ayanamsha for a given JD (Chitrapaksha — Government of India standard)
// ══════════════════════════════════════════════════════════════════════════════

function lahiriAyanamsha(JD) {
  // Lahiri value at J2000 = 23.855° approximately
  // Rate = 50.2388475 arcsec/year
  const T   = (JD - 2451545.0) / 36525.0;
  const ayan = 23.85045311 + (50.2388475 / 3600) * T * 36525 / 365.25;
  return norm360(ayan);
}

// Convert tropical longitude to sidereal (Lahiri)
function toSidereal(tropicalLon, ayanamsha) {
  return norm360(tropicalLon - ayanamsha);
}

// ══════════════════════════════════════════════════════════════════════════════
//  SECTION 4: ASCENDANT (LAGNA) CALCULATION
//  Using RAMC + obliquity + geographic latitude
// ══════════════════════════════════════════════════════════════════════════════

function obliquity(T) {
  // Mean obliquity of ecliptic (IAU)
  const e0 = 23 + 26/60 + 21.448/3600;
  const de = -(46.8150 * T + 0.00059 * T*T - 0.001813 * T*T*T) / 3600;
  return e0 + de;
}

function computeASC(JD, lat, lon) {
  const T = (JD - 2451545.0) / 36525.0;
  // Greenwich Sidereal Time
  const GMST = norm360(280.46061837 + 360.98564736629 * (JD - 2451545.0) + 0.000387933 * T * T - T * T * T / 38710000);
  const LMST = norm360(GMST + lon); // Local Mean Sidereal Time in degrees
  const eps  = obliquity(T) * DEG;
  const RAMC = LMST * DEG; // RAMC in radians

  // Ascendant formula
  const tanASC = -Math.cos(RAMC) / (Math.sin(eps) * Math.tan(lat * DEG) + Math.cos(eps) * Math.sin(RAMC));
  let ASC = Math.atan(tanASC) * RAD;

  // Correct quadrant
  if (Math.cos(RAMC) < 0) ASC += 180;
  else if (tanASC < 0) ASC += 360;

  return norm360(ASC); // Tropical ASC
}

// ══════════════════════════════════════════════════════════════════════════════
//  SECTION 5: WHOLE SIGN HOUSE ASSIGNMENT
// ══════════════════════════════════════════════════════════════════════════════

const SIGNS = [
  "Aries","Taurus","Gemini","Cancer","Leo","Virgo",
  "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"
];

function lonToSign(lon) { return SIGNS[Math.floor(lon / 30)]; }
function lonToDegree(lon) { return lon % 30; }

function buildWholeSignHouses(lagnaSign) {
  const lagnaIdx = SIGNS.indexOf(lagnaSign);
  const houseToSign = {};
  for (let h = 1; h <= 12; h++) {
    houseToSign[h] = SIGNS[(lagnaIdx + h - 1) % 12];
  }
  return houseToSign;
}

function assignPlanetsToHouses(planets, lagnaSign) {
  const houses = {};
  for (let h = 1; h <= 12; h++) houses[h] = [];
  const houseToSign = buildWholeSignHouses(lagnaSign);

  for (const [planet, data] of Object.entries(planets)) {
    const sign = lonToSign(data.longitude);
    for (const [h, s] of Object.entries(houseToSign)) {
      if (s === sign) {
        houses[parseInt(h)].push(planet);
        break;
      }
    }
  }
  return houses;
}

// ══════════════════════════════════════════════════════════════════════════════
//  SECTION 6: D9 NAVAMSHA CALCULATION
//  Each sign (30°) is divided into 9 equal navamshas of 3°20' (3.333°)
// ══════════════════════════════════════════════════════════════════════════════

// Navamsha starting signs by sign group
// Fire signs start from Aries, Earth from Capricorn, Air from Libra, Water from Cancer
const NAVAMSHA_START = {
  Aries:0, Taurus:9, Gemini:6, Cancer:3, Leo:0, Virgo:9,
  Libra:6, Scorpio:3, Sagittarius:0, Capricorn:9, Aquarius:6, Pisces:3
};

function getNavamshaSign(tropicalLon) {
  const sign      = lonToSign(tropicalLon);
  const degInSign = lonToDegree(tropicalLon);
  const navNum    = Math.floor(degInSign / (10/3)); // 0-8
  const startIdx  = NAVAMSHA_START[sign];
  return SIGNS[(startIdx + navNum) % 12];
}

function buildD9(siderealPlanets, siderealASC) {
  // For D9 we use sidereal positions
  const d9Planets = {};
  for (const [planet, data] of Object.entries(siderealPlanets)) {
    const navSign = getNavamshaSign(data.longitude);
    d9Planets[planet] = { ...data, navamshaSign: navSign };
  }
  const d9Lagna = getNavamshaSign(siderealASC);
  return { planets: d9Planets, lagnaSign: d9Lagna };
}

// ══════════════════════════════════════════════════════════════════════════════
//  SECTION 7: VIMSHOTTARI DASHA
// ══════════════════════════════════════════════════════════════════════════════

const NAKSHATRAS = [
  "Ashwini","Bharani","Krittika","Rohini","Mrigashirsha","Ardra",
  "Punarvasu","Pushya","Ashlesha","Magha","Purva Phalguni","Uttara Phalguni",
  "Hasta","Chitra","Swati","Vishakha","Anuradha","Jyeshtha",
  "Mula","Purva Ashadha","Uttara Ashadha","Shravana","Dhanishtha","Shatabhisha",
  "Purva Bhadrapada","Uttara Bhadrapada","Revati"
];

const NAKSHATRA_LORDS = [
  "Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury", // 1-9
  "Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury", // 10-18
  "Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury"  // 19-27
];

const DASHA_YEARS = {
  Ketu:7, Venus:20, Sun:6, Moon:10, Mars:7, Rahu:18, Jupiter:16, Saturn:19, Mercury:17
};

const DASHA_ORDER = ["Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury"];

function computeVimshottari(moonLonSidereal, birthJD) {
  const moonDegInNakshatra = moonLonSidereal % (360/27);
  const nakshatraIdx = Math.floor(moonLonSidereal / (360/27));
  const nakshatraLen = 360/27; // 13.3333°

  const nakshatra    = NAKSHATRAS[nakshatraIdx];
  const lordIdx      = nakshatraIdx % 9;
  const startLord    = DASHA_ORDER[lordIdx];

  // Balance of first Dasha at birth
  const consumed     = moonDegInNakshatra / nakshatraLen; // fraction consumed
  const balance      = 1 - consumed;
  const firstDashaYears = DASHA_YEARS[startLord] * balance;

  // Build all dashas
  const dashas = [];
  const startLordPos = DASHA_ORDER.indexOf(startLord);
  let currentDate = new Date((birthJD - 2440587.5) * 86400000); // JD to Date

  for (let i = 0; i < 9; i++) {
    const lord = DASHA_ORDER[(startLordPos + i) % 9];
    const years = i === 0 ? firstDashaYears : DASHA_YEARS[lord];
    const startDate = new Date(currentDate);
    const endDate   = new Date(currentDate);
    endDate.setFullYear(endDate.getFullYear() + Math.floor(years));
    endDate.setDate(endDate.getDate() + Math.round((years % 1) * 365.25));

    // Antar Dasas
    const antarDasas = [];
    const antarStartPos = DASHA_ORDER.indexOf(lord);
    let antarCurrent = new Date(startDate);
    for (let j = 0; j < 9; j++) {
      const antarLord = DASHA_ORDER[(antarStartPos + j) % 9];
      const antarYears = years * DASHA_YEARS[antarLord] / 120;
      const antarStart = new Date(antarCurrent);
      const antarEnd   = new Date(antarCurrent);
      antarEnd.setFullYear(antarEnd.getFullYear() + Math.floor(antarYears));
      antarEnd.setDate(antarEnd.getDate() + Math.round((antarYears % 1) * 365.25));
      antarDasas.push({
        lord: antarLord,
        startDate: antarStart.toISOString().split("T")[0],
        endDate:   antarEnd.toISOString().split("T")[0],
        years:     Math.round(antarYears * 100) / 100
      });
      antarCurrent = new Date(antarEnd);
    }

    dashas.push({
      lord,
      startDate: startDate.toISOString().split("T")[0],
      endDate:   endDate.toISOString().split("T")[0],
      years:     Math.round(years * 100) / 100,
      antarDasas
    });
    currentDate = new Date(endDate);
  }

  return { nakshatra, nakshataLord: startLord, dashas };
}

// ══════════════════════════════════════════════════════════════════════════════
//  SECTION 8: GEOCODING via Nominatim
// ══════════════════════════════════════════════════════════════════════════════

async function geocode(place) {
  const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(place)}&format=json&limit=1`;
  const res = await fetch(url, { headers: { "User-Agent": "JyotishPrecisionApp/3.0" } });
  const data = await res.json();
  if (!data || !data[0]) throw new Error(`Place not found: ${place}`);
  return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon), displayName: data[0].display_name };
}

// Simple timezone offset from longitude (±1 per 15°) — refined by UTC offset provided
function lonToUtcOffset(lng) { return Math.round(lng / 15); }

// ══════════════════════════════════════════════════════════════════════════════
//  SECTION 9: RETROGRADE DETECTION
// ══════════════════════════════════════════════════════════════════════════════

function isRetrograde(planet, JD) {
  if (planet === "Sun" || planet === "Moon" || planet === "Rahu" || planet === "Ketu") return false;
  const T1 = (JD - 2451545.0) / 36525.0;
  const T2 = ((JD + 1) - 2451545.0) / 36525.0;
  let lon1, lon2;
  if (planet === "Mercury") { lon1 = innerPlanetPosition(T1, false).longitude; lon2 = innerPlanetPosition(T2, false).longitude; }
  else if (planet === "Venus")   { lon1 = innerPlanetPosition(T1, true).longitude;  lon2 = innerPlanetPosition(T2, true).longitude; }
  else if (planet === "Mars")    { lon1 = marsPosition(T1).longitude;    lon2 = marsPosition(T2).longitude; }
  else if (planet === "Jupiter") { lon1 = jupiterPosition(T1).longitude; lon2 = jupiterPosition(T2).longitude; }
  else if (planet === "Saturn")  { lon1 = saturnPosition(T1).longitude;  lon2 = saturnPosition(T2).longitude; }
  else return false;

  // Retrograde if longitude decreases (accounting for 360° wrap)
  let diff = lon2 - lon1;
  if (diff > 180) diff -= 360;
  if (diff < -180) diff += 360;
  return diff < 0;
}

// ══════════════════════════════════════════════════════════════════════════════
//  SECTION 10: NAKSHATRA + PADA FOR ANY PLANET
// ══════════════════════════════════════════════════════════════════════════════

function getNakshatraPada(sidLon) {
  const nakshatraSpan = 360 / 27;
  const padaSpan      = nakshatraSpan / 4;
  const nIdx  = Math.floor(sidLon / nakshatraSpan);
  const degIn = sidLon % nakshatraSpan;
  const pada  = Math.floor(degIn / padaSpan) + 1;
  return { nakshatra: NAKSHATRAS[nIdx % 27], pada };
}

// ══════════════════════════════════════════════════════════════════════════════
//  MAIN HANDLER
// ══════════════════════════════════════════════════════════════════════════════

export async function onRequestPost(context) {
  try {
    const body     = await context.request.json();
    const { name, dob, tob, place, utcOffset, ayanamsha: ayanChoice } = body;

    if (!dob || !tob || !place) {
      return Response.json({ error:"Date of birth, time of birth, and place are required." }, { status:400 });
    }

    // Parse date and time
    const [year, month, day] = dob.split("-").map(Number);
    const [hour, minute]     = tob.split(":").map(Number);

    // Geocode
    const geo = await geocode(place);

    // UTC offset: user-provided or computed from longitude
    const utcOff = utcOffset != null ? parseFloat(utcOffset) : lonToUtcOffset(geo.lng);

    // Convert local time to UTC
    const utcHour = hour - utcOff;
    const JD = dateToJulianDay(year, month, day, utcHour, minute, 0);

    // Ayanamsha
    const ayan = lahiriAyanamsha(JD);

    // Tropical planet positions
    const tropPositions = computePlanetPositions(JD);

    // Sidereal positions
    const sidPositions = {};
    for (const [planet, data] of Object.entries(tropPositions)) {
      sidPositions[planet] = {
        longitude: toSidereal(data.longitude, ayan),
        latitude:  data.latitude,
        retrograde: isRetrograde(planet, JD)
      };
    }

    // Ascendant (tropical then sidereal)
    const tropASC    = computeASC(JD, geo.lat, geo.lng);
    const siderealASC = toSidereal(tropASC, ayan);
    const lagnaSign  = lonToSign(siderealASC);
    const lagnaDeg   = lonToDegree(siderealASC);

    // D1 house assignment
    const d1Houses = assignPlanetsToHouses(sidPositions, lagnaSign);

    // D9
    const d9Data   = buildD9(sidPositions, siderealASC);
    const d9Houses = assignPlanetsToHouses(d9Data.planets, d9Data.lagnaSign);

    // Dasha
    const dasha = computeVimshottari(sidPositions.Moon.longitude, JD);

    // Planet details table
    const planets = {};
    const PLANET_LIST = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu"];
    for (const p of PLANET_LIST) {
      const sid = sidPositions[p];
      const np  = getNakshatraPada(sid.longitude);
      const sign = lonToSign(sid.longitude);
      const deg  = lonToDegree(sid.longitude);
      const d9sign = d9Data.planets[p]?.navamshaSign || "";
      planets[p] = {
        longitude:  Math.round(sid.longitude * 1000) / 1000,
        latitude:   Math.round(sid.latitude  * 1000) / 1000,
        sign,
        degree:     Math.round(deg * 100) / 100,
        nakshatra:  np.nakshatra,
        pada:       np.pada,
        retrograde: sid.retrograde,
        d9sign
      };
    }

    // Degree map for combustion check (analyze.js)
    const degrees = {};
    for (const p of PLANET_LIST) degrees[p] = sidPositions[p].longitude;

    const latitudes = {};
    for (const p of PLANET_LIST) latitudes[p] = sidPositions[p].latitude;

    return Response.json({
      success: true,
      input: { name, dob, tob, place: geo.displayName, lat: geo.lat, lng: geo.lng, utcOffset: utcOff },
      ayanamsha: Math.round(ayan * 10000) / 10000,
      d1: {
        lagnaSign,
        lagnaDegree: Math.round(lagnaDeg * 100) / 100,
        houses: d1Houses,
        degrees,
        latitudes
      },
      d9: {
        lagnaSign: d9Data.lagnaSign,
        houses: d9Houses,
        degrees: Object.fromEntries(PLANET_LIST.map(p => [p, d9Data.planets[p]?.longitude || 0])),
        latitudes: {}
      },
      planets,
      dasha
    });

  } catch (error) {
    return Response.json({ error: error.message || "Chart calculation failed." }, { status:500 });
  }
}
